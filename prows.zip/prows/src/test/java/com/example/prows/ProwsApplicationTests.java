package com.example.prows;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
